import db
from business import Pokemon, Party

def add_pokemon(pokemon_all):
    name = input("Pokemon name: ")
    type_primary = input("Primary type: ")
    type_secondary = input("Secondary type: ")
    hp = get_hp()
    atk = get_atk()
    defn = get_defn()
    spatk = get_spatk()
    spdefn = get_spdefn()
    spd = get_spd()
    party_order = pokemon_all.count + 1

    pokemon = Pokemon(name, type_primary, type_secondary, hp, atk, defn, spatk, spdefn, spd, party_order)
    pokemon_all.add(pokemon)
    db.add_pokemon(pokemon)
    print(f"{name} was added.\n")

def get_hp():
    while True:
        try:
            hp = int(input("HP stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if hp < 0 or hp > 300:
            print("Invalid entry. HP must be from 0 to 300.")
        else:
            return hp

def get_atk():
    while True:
        try:
            atk = int(input("Attack stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if atk < 0 or atk > 300:
            print("Invalid entry. Attack must be from 0 to 300.")
        else:
            return atk

def get_defn():
    while True:
        try:
            defn = int(input("Defense stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if defn < 0 or defn > 300:
            print("Invalid entry. Defense must be from 0 to 300.")
        else:
            return defn

def get_spatk():
    while True:
        try:
            spatk = int(input("Special Attack stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if spatk < 0 or spatk > 300:
            print("Invalid entry. Special Attack must be from 0 to 300.")
        else:
            return spatk

def get_spdefn():
    while True:
        try:
            spdefn = int(input("Special Defense stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if spdefn < 0 or spdefn > 300:
            print("Invalid entry. Special Defense must be from 0 to 300.")
        else:
            return spdefn

def get_spd():
    while True:
        try:
            spd = int(input("Speed stat: "))
        except ValueError:
            print("Invalid integer. Try again.")
            continue

        if spd < 0 or spd > 300:
            print("Invalid entry. Speeed must be from 0 to 300.")
        else:
            return spd

def get_party_number(pokemon_all, prompt):
    while True:
        try:
            number = int(input(prompt))
        except ValueError:
            print("Invalid integer. Please try again.")
            continue

        if number < 1 or number > pokemon_all.count:
            print("Invalid party number. Please try again.")
        else:
            return number
        
def delete_pokemon(pokemon_all):
    number = get_party_number(pokemon_all, "Party number: ")
    pokemon = pokemon_all.remove(number)
    db.delete_pokemon(pokemon)
    db.update_party_order(pokemon_all)
    print(f"{pokemon.name} was deleted.\n")

def move_pokemon(pokemon_all):
    old_party_number = get_party_number(pokemon_all, "Current party number: ")
    pokemon = pokemon_all.get(old_party_number)
    print (f"{pokemon.name} was selected.")
    new_party_number = get_party_number(pokemon_all, "New party number: ")

    pokemon_all.move(old_party_number, new_party_number)
    db.update_party_order(pokemon_all)
    print(f"{pokemon.name} was moved.\n")

def edit_pokemon(pokemon_all):
    number = get_party_number(pokemon_all, "Party number: ")
    pokemon = pokemon_all.get(number)
    print(f"{pokemon.name} was selected.\n")

    pokemon.name = input("New Pokemon name: ")
    pokemon.typeOne = input("Primary Type: ")
    pokemon.typeTwo = input("Secondary Type: ")
    pokemon.hp = get_hp()
    pokemon.atk = get_atk()
    pokemon.defn = get_defn()
    pokemon.spatk = get_spatk()
    pokemon.spdefn = get_spdefn()
    pokemon.spd = get_spd()
    db.update_pokemon(pokemon)
    print(f"{pokemon.name} was updated.\n")

def display_party(pokemon_all):
    if pokemon_all == None:
        print("There are currently no Pokemon in the party.\n")
    else:
        print(f"{'':3}{'Name':15}{'Primary':10}{'Secondary':10}{'HP':>6}\t{'Attack':>6}\t{'Defense':>6}\t{'SpAtk':>6}\t{'SpDef':>6}\t{'Speed':>6}")
        print("=" *90)
        for pokemon in pokemon_all:
            print(f"{pokemon.partyOrder:<3d}{pokemon.name:15}{pokemon.typeOne:10}{pokemon.typeTwo:10}" + \
                  f"{pokemon.hp:6d}\t{pokemon.atk:6d}\t{pokemon.defn:6d}\t{pokemon.spatk:6d}\t{pokemon.spdefn:6d}\t{pokemon.spd:6d}")
    print()

def display_separator():
    print("=" * 90)

def display_title():
    print("                       Pokemon Tracker")

def display_menu():
    print("Menu Options")
    print("1 = Display Party")
    print("2 = Add Pokemon")
    print("3 = Delete Pokemon")
    print("4 = Move Pokemon")
    print("5 = Update Pokemon")
    print("6 = Quit Program")
    print()

def main():
    display_separator()
    display_title()
    display_menu()

    db.connect()
    pokemon_all = db.get_pokemon_all()
    if pokemon_all == None:
        pokemon_all = Party()

    display_separator()

    while True:
        try:
            option = int(input("Menu Option: "))
        except ValueError:
            option = -1

        if option == 1:
            display_party(pokemon_all)
        elif option == 2:
            add_pokemon(pokemon_all)
            pokemon = db.get_pokemon_all()
        elif option == 3:
            delete_pokemon(pokemon_all)
        elif option == 4:
            move_pokemon(pokemon_all)
        elif option == 5:
            edit_pokemon(pokemon_all)
        elif option == 6:
            db.close()
            print("Bye!")
            break
        else:
            print("Not a valid option. Please try again.\n")
            display_menu()

if __name__ == "__main__":
    main()
