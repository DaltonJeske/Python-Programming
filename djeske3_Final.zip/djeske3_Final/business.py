from dataclasses import dataclass

@dataclass
class Pokemon:
    name:str = ""
    typeOne:str = ""
    typeTwo:str = ""
    hp:int = 0
    atk:int = 0
    defn:int = 0
    spatk:int = 0
    spdefn:int = 0
    spd:int = 0
    partyOrder:int = 0
    pokemonID:int = 0
    
  
class Party:
    def __init__(self):
        self.__list = []

    @property
    def count(self):
        return len(self.__list)

    def add(self, pokemon):
        return self.__list.append(pokemon)

    def remove(self, number):
        return self.__list.pop(number-1)

    def get(self, number):
        return self.__list[number-1]

    def set(self, number, pokemon):
        self.__list[number-1] = pokemon

    def move(self, oldNumber, newNumber):
        pokemon = self.__list.pop(oldNumber-1)
        self.__list.insert(newNumber-1, pokemon)

    def __iter__(self):
        for pokemon in self.__list:
            yield pokemon
             
def main(): 
    party = Party()

    for pokemon in Party:
        print(pokemon.partyOrder, pokemon.name, pokemon.typeOne, pokemon.typeTwo,
              pokemon.hp, pokemon.atk, pokemon.defn, pokemon.spatk, pokemon.spdefn,
              pokemon.spd)

    print("Bye!")

if __name__ == "__main__":
    main()
