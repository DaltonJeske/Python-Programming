import sqlite3
from contextlib import closing

from business import Pokemon, Party

conn = None

def connect():
    global conn
    if not conn:
        DB_FILE = "final.sqlite"
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row

def close():
    if conn:
        conn.close()

def make_pokemon(row):
    return Pokemon(row["name"], row["typeOne"], row["typeTwo"], row["hp"], row["atk"],
                   row["defn"], row["spatk"], row["spdefn"], row["spd"], row["partyOrder"], row["pokemonID"])

def get_pokemon_all():
    query = '''SELECT name, typeOne, typeTwo, hp, atk, defn, spatk, spdefn, spd, partyOrder, pokemonID
                FROM Pokemon ORDER BY partyOrder'''
    with closing(conn.cursor()) as c:
        c.execute(query)
        results = c.fetchall()

    pokemon_all = Party()
    for row in results:
        pokemon = make_pokemon(row)
        pokemon_all.add(pokemon)
    return pokemon_all

def get_pokemon(id):
    query = '''SELECT name, typeOne, typeTwo, hp, atk, defn, spatk, spdefn, spd, partyOrder, pokemonID
                FROM Pokemon
                WHERE pokemonID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(query, (id,))
        row = c.fetchone()
        if row:
            pokemon = make_pokemon(row)
            return pokemon
        else:
            return None

def add_pokemon(pokemon):
        sql = '''INSERT INTO Pokemon
                (name, typeOne, typeTwo, hp, atk, defn, spatk, spdefn,
                spd, partyOrder)
                Values
                    (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'''
        with closing(conn.cursor()) as c:
            c.execute(sql, (pokemon.name, pokemon.typeOne, pokemon.typeTwo, pokemon.hp,
                            pokemon.atk, pokemon.defn, pokemon.spatk, pokemon.spdefn, pokemon.spd, pokemon.partyOrder))
            conn.commit()

def delete_pokemon(pokemon):
    sql = '''DELETE FROM Pokemon WHERE pokemonID = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (pokemon.pokemonID,))
        conn.commit()

def update_party_order(Party):
    for num, pokemon in enumerate(Party, start=1):
        pokemon.partyOrder = num
        sql = '''UPDATE Pokemon
                    SET partyOrder = ?
                    WHERE pokemonID = ?'''
        with closing(conn.cursor()) as c:
            c.execute(sql, (pokemon.partyOrder, pokemon.pokemonID))
    conn.commit()

def update_pokemon(pokemon):  #useful for evolutions
    sql = '''UPDATE Pokemon
            SET name = ?,
                typeOne = ?,
                typeTwo = ?,
                hp = ?,
                atk = ?,
                defn = ?,
                spatk = ?,
                spdefn = ?,
                spd = ?
            WHERE partyOrder = ?'''
    with closing(conn.cursor()) as c:
        c.execute(sql, (pokemon.name, pokemon.typeOne, pokemon.typeTwo, pokemon.hp,
                        pokemon.atk, pokemon.defn, pokemon.spatk, pokemon.spdefn, pokemon.spd, pokemon.partyOrder))
        conn.commit()

def main():
    connect()
    pokemon_all = get_pokemon_all()
    for pokemon in pokemon_all:
        print(pokemon.pokemonID, pokemon.partyOrder, pokemon.name, pokemon.typeOne, pokemon.typeTwo, pokemon.hp,
                pokemon.atk, pokemon.defn, pokemon.spatk, pokemon.spdefn, pokemon.spd)

if __name__ == "__main__":
    main()
        


